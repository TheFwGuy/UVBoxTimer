//
// Screen_HY28A_SRAM.cpp
// Library C++ code
// ----------------------------------
// Developed with embedXcode
// http:// embedXcode.weebly.com
//
// Project SCREEN_library_main
//
// Created by Rei VILO, Mar 06, 2013
// embedXcode.weebly.com
//
// ***
// Copyright © Rei VILO, 2013-2014
// Licence All rights reserved
//
// See HY28A_SRAM_screen.h and ReadMe.txt for references
//

#if defined(__LM4F120H5QR__)

// Library header
#include "Screen_HY28A_SRAM.h"

///
/// @name	HY28A size
/// @{

#define HY28A_WIDTH  240
#define HY28A_HEIGHT 320

/// @}

uint8_t HY28A_buffer[max(HY28A_WIDTH, HY28A_HEIGHT)][2];

///
/// @name	HY28A constants
/// @{

#define ILIGRAMMODE 0x03 ///< Define scan mode
#define TOUCH_X     0xd0 ///< Read X value
#define TOUCH_Y     0x90 ///< Read Y value
#define TOUCH_Z1    0xb0 ///< Read Z1 value
#define TOUCH_Z2    0xc0 ///< Read Z2 value
#define TOUCH_TRIM  0x10 ///< Touch threshold
#define LCD_HEIGHT  320  ///< Vertical
#define LCD_WIDTH   240  ///< Horizontal


#define SPI_START   0x70              ///< Start byte for SPI transfer
#define SPI_RD      0x01              ///< WR bit 1 within start
#define SPI_WR      0x00              ///< WR bit 0 within start
#define SPI_DATA    0x02              ///< RS bit 1 within start byte
#define SPI_INDEX   0x00              ///< RS bit 0 within start byte 0x00

/// @}

///
/// @name	Instruction Set
///
/// @{

#define SRAM_READ         0b00000011  ///< Read data from memory array beginning at selected address
#define SRAM_WRITE        0b00000010  ///< Write data to memory array beginning at selected address
#define SRAM_READ_STATUS  0b00000101  ///< Read STATUS register
#define SRAM_WRITE_STATUS 0b00000001  ///< Write STATUS register

/// @}

/// @section Initialisation
/// @name   Status Register Instruction
///
/// @{

#define SRAM_BYTE_MODE     0b00000000  ///< Byte mode (default operation)
#define SRAM_PAGE_MODE     0b10000000  ///< Page mode
#define SRAM_SEQUENCE_MODE 0b01000000  ///< Sequential mode
#define SRAM_RESERVED_MODE 0b11000000  ///< Reserved
#define SRAM_HOLD_MODE     0b00000001  ///< Set this bit to DISABLE hold mode

/// @}

// Class
Screen_HY28A_SRAM::Screen_HY28A_SRAM(uint8_t pinScreenChipSelect, uint8_t pinScreenReset,
                               uint8_t pinTouchChipSelect, uint8_t pinTouchSerialClock,
                               uint8_t pinTouchSerialDataMOSI, uint8_t pinTouchSerialDataMISO)
{
    _pinScreenChipSelectNumber    = pinScreenChipSelect;
    _pinScreenReset         = pinScreenReset;
    _pinTouchChipSelectNumber     = pinTouchChipSelect;
    _pinTouchSerialClock    = pinTouchSerialClock;
    _pinTouchSerialDataMOSI = pinTouchSerialDataMOSI;
    _pinTouchSerialDataMISO = pinTouchSerialDataMISO;
};


void Screen_HY28A_SRAM::_orientCoordinates(uint16_t &x1, uint16_t &y1)
{
	switch (_orientation) {
        case 0:  // ok
            break;
        case 1: // ok
            y1 = screenSizeY()-1 - y1;
            _swap(x1, y1);
            break;
        case 2: // ok
            x1 = screenSizeX()-1 - x1;
            y1 = screenSizeY()-1 - y1;
            break;
        case 3: // ok
            x1 = screenSizeX()-1 - x1;
            _swap(x1, y1);
            break;
	}
}


void Screen_HY28A_SRAM::_setCursor(uint16_t x0, uint16_t y0)
{
	_orientCoordinates(x0, y0);
   	_writeRegister(0x0020, x0);
	_writeRegister(0x0021, y0);
    _writeCommand(0x0022);                                                      // ready for write or read
}


void Screen_HY28A_SRAM::_setWindow(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2)
{
    _orientCoordinates(x1, y1);
	_orientCoordinates(x2, y2);
    
    _writeRegister(0x20, x1);
	_writeRegister(0x21, y1);
    
    if (x1>x2) _swap(x1, x2);
    if (y1>y2) _swap(y1, y2);
    
	_writeRegister(0x50, x1);
	_writeRegister(0x52, y1);
	_writeRegister(0x51, x2);
	_writeRegister(0x53, y2);
    _writeCommand(0x0022);                                                      // ready for write or read
}

void Screen_HY28A_SRAM::_closeWindow()
{
    _setWindow(0, 0, screenSizeX()-1, screenSizeY()-1);
}


void Screen_HY28A_SRAM::begin()
{
    // Hardware SPI for the screen
    _pinScreenChipSelect.begin(_pinScreenChipSelectNumber);
    
    _flagStorage = false;
    
    // SPI mode
#if (SPI_MODE == SOFTWARE_SPI)
    _pinScreenSerialClock = PB_4;
    _pinScreenSerialDataMOSI = PB_7;
    _pinScreenSerialDataMISO = PB_6;
    
    pinMode(_pinScreenSerialDataMOSI, OUTPUT);
    pinMode(_pinScreenSerialDataMISO, INPUT);
    pinMode(_pinScreenSerialClock, OUTPUT);
    
#else                                                                           // normal hardware SPI
    
#if defined(__MSP430G2553__)
#define SPI_LCD SPI
    
    SPI_LCD.begin();
    SPI_LCD.setClockDivider(SPI_CLOCK_DIV2);                                    // for MSP430G2553
    SPI_LCD.setBitOrder(MSBFIRST);
    SPI_LCD.setDataMode(SPI_MODE3);                                             // SPI_MODE2 or SPI_MODE3
    
#elif defined(__LM4F120H5QR__)
#define SPI_LCD SPI
    
    //    SPI_LCD.setModule(2);
    SPI_LCD.begin();
    SPI_LCD.setClockDivider(SPI_CLOCK_DIV2);                                    // for LM4F with 16000000
    SPI_LCD.setBitOrder(MSBFIRST);
    SPI_LCD.setDataMode(SPI_MODE2);                                             // SPI_MODE2 or SPI_MODE3
    
#endif                                                                          // end MCU
#endif                                                                          // end SPI_MODE
    
#if (USE_SPI_SRAM == 1)
    _beginSRAM();
    _flagStorage = true;
#endif                                                                          // end USE_SPI_SRAM
    
    // Software SPI for the touch controller
    _pinTouchChipSelect.begin(_pinTouchChipSelectNumber);
    pinMode(_pinTouchSerialClock, OUTPUT);
    pinMode(_pinTouchSerialDataMOSI, OUTPUT);
    pinMode(_pinTouchSerialDataMISO, INPUT);
    
    //    digitalWrite(_pinScreenReset, LOW);
    //    delay(10);
    //    digitalWrite(_pinScreenReset, HIGH);
    //    delay(10);
    
	// uint16_t DeviceCode;
    // DeviceCode = LCD_ReadReg(0x0000);		// Read ID
    // Serial.println(DeviceCode, HEX);
    
    _writeRegister(0x00, 0x0000);                                               // Start oscillation
    _writeRegister(0x01, 0x0100);                                               // Driver Output Contral
    _writeRegister(0x02, 0x0700);                                               // LCD Driver Waveform Contral
    _writeRegister(0x03, 0x1038);                                               // Set the scan mode
    _writeRegister(0x04, 0x0000);                                               // Scalling Contral
    _writeRegister(0x08, 0x0202);                                               // Display Contral 2
    _writeRegister(0x09, 0x0000);                                               // Display Contral 3
    _writeRegister(0x0a, 0x0000);                                               // Frame Cycle Contal
    _writeRegister(0x0c, (1<<0));                                               // Extern Display Interface Contral 1
    _writeRegister(0x0d, 0x0000);                                               // Frame Maker Position
    _writeRegister(0x0f, 0x0000);                                               // Extern Display Interface Contral 2
    delay(50);
    _writeRegister(0x07, 0x0101);                                               // Display Contral
    delay(50);
    _writeRegister(0x10, (1<<12)|(0<<8)|(1<<7)|(1<<6)|(0<<4));                  // Power Control 1
    _writeRegister(0x11, 0x0007);                                               // Power Control 2
    _writeRegister(0x12, (1<<8)|(1<<4)|(0<<0));                                 // Power Control 3
    _writeRegister(0x13, 0x0b00);                                               // Power Control 4
    _writeRegister(0x29, 0x0000);                                               // Power Control 7
    _writeRegister(0x2b, (1<<14)|(1<<4));
	
    _writeRegister(0x50, 0);                                                    // Set X Start
    _writeRegister(0x51, 239);	                                                // Set X End
    _writeRegister(0x52, 0);	                                                // Set Y Start
    _writeRegister(0x53, 319);	                                                // Set Y End
    delay(50);
    
    _writeRegister(0x60, 0x2700);                                               // Driver Output Control
    _writeRegister(0x61, 0x0001);                                               // Driver Output Control
    _writeRegister(0x6a, 0x0000);                                               // Vertical Srcoll Control
    
    _writeRegister(0x80, 0x0000);                                               // Display Position? Partial Display 1
    _writeRegister(0x81, 0x0000);                                               // RAM Address Start? Partial Display 1
    _writeRegister(0x82, 0x0000);                                               // RAM Address End-Partial Display 1
    _writeRegister(0x83, 0x0000);                                               // Displsy Position? Partial Display 2
    _writeRegister(0x84, 0x0000);                                               // RAM Address Start? Partial Display 2
    _writeRegister(0x85, 0x0000);                                               // RAM Address End? Partial Display 2
    
    _writeRegister(0x90, (0<<7)|(16<<0));                                       // Frame Cycle Contral
    _writeRegister(0x92, 0x0000);                                               // Panel Interface Contral 2
    _writeRegister(0x93, 0x0001);                                               // Panel Interface Contral 3
    _writeRegister(0x95, 0x0110);                                               // Frame Cycle Contral
    _writeRegister(0x97, (0<<8));
    _writeRegister(0x98, 0x0000);                                               // Frame Cycle Contral
    _writeRegister(0x07, 0x0133);
    delay(100);                                                                 // delay 50 ms
    
    setBacklight(true);
    setOrientation(0);
    
    _screenWidth = HY28A_WIDTH;
    _screenHeigth = HY28A_HEIGHT;
    _penSolid  = false;
    _fontSolid = true;
    _flagRead = true;                                                           // screen readable
    
    _touchXmin = 108;
    _touchXmax = 1919;
    _touchYmin = 88;
    _touchYmax = 1880;
    _touchTrim = TOUCH_TRIM;                                                    // touch available
    
    clear();
}

String Screen_HY28A_SRAM::WhoAmI()
{
    return "HY28A + SRAM screen";
}


void Screen_HY28A_SRAM::invert(boolean flag) {
    // _writeCommand(flag ? HY28A_INVON : HY28A_INVOFF);
}


void Screen_HY28A_SRAM::setBacklight(boolean flag) {
    // if (_backlight!=NULL) digitalWrite(_backlight, flag);
}

void Screen_HY28A_SRAM::_setOrientation(uint8_t orientation)
{
    // _orientation = orientation % 4;
//    LCD_screen_font::setOrientation(orientation);
    
    switch (_orientation) {
        case 0:
            //                                     hvO
            _writeRegister(ILIGRAMMODE, 0x1000 + 0b00110000);
            break;
        case 1:
            //                                     hvO
            _writeRegister(ILIGRAMMODE, 0x1000 + 0b00101000);
            break;
        case 2:
            //                                     hvO
            _writeRegister(ILIGRAMMODE, 0x1000 + 0b00000000);
            break;
        case 3:
            //                                     hvO
            _writeRegister(ILIGRAMMODE, 0x1000 + 0b00011000);
            break;
    }
}

void Screen_HY28A_SRAM::setDisplay(boolean flag) {
    // if (_backlight!=NULL) setBacklight(flag);
}

uint16_t Screen_HY28A_SRAM::readPixel(uint16_t x1, uint16_t y1)
{
	uint16_t data;
    
	_setCursor(x1, y1);
	data = _readData();
    
	return data;
}

void Screen_HY28A_SRAM::_setPoint(uint16_t x1, uint16_t y1, uint16_t colour)
{
    _setWindow(x1, y1, x1, y1);
    _writeData88(highByte(colour), lowByte(colour));
}

// Utilities
void Screen_HY28A_SRAM::_writeCommand(uint8_t command8)
{
    _writeBeginSPI();
    
    // SPI write data
    _writeSPI(SPI_START | SPI_WR | SPI_INDEX);                                  // write : RS = 0, RW = 0
    _writeSPI(0x00);                                                            // write D8..D15
    _writeSPI(command8);                                                        // write D0..D7
    
    _writeEndSPI();
    
}

void Screen_HY28A_SRAM::_writeData16(uint16_t data16)
{
    _writeBeginSPI();
    
    _writeSPI(SPI_START | SPI_WR | SPI_DATA);                                   // write : RS = 1, RW = 0
    _writeSPI(highByte(data16));                                                // write D8..D15
    _writeSPI(lowByte(data16));                                                 // write D0..D7
    
    _writeEndSPI();
    
}

void Screen_HY28A_SRAM::_writeData88(uint8_t dataHigh8, uint8_t dataLow8)
{
    _writeBeginSPI();
    
    _writeSPI(SPI_START | SPI_WR | SPI_DATA);                                   // write : RS = 1, RW = 0
    _writeSPI(dataHigh8);                                                       // write D8..D15
    _writeSPI(dataLow8);                                                        // write D0..D7
    
    _writeEndSPI();
    
}

uint16_t Screen_HY28A_SRAM::_readData()
{
	uint16_t data;
    
    _writeBeginSPI();
    
	_writeSPI(SPI_START | SPI_RD | SPI_DATA);                                   // read: RS = 1, RW = 1
	_readSPI();                                                                 // dummy read
	_readSPI();                                                                 // dummy read
	_readSPI();                                                                 // dummy read
	_readSPI();                                                                 // dummy read
	_readSPI();                                                                 // dummy read
    
	data   = _readSPI();                                                        // read D8..D15
	data <<= 8;
	data  |= _readSPI();                                                        // read D0..D7
    
    _writeEndSPI();
    
    /// @bug 1st bit is useless!
    ///
    data <<= 1;
    
    // Convert B5G5R5 into R5G6B5
    // Colour         BBBBBxGGGGGRRRRR                     BBBBBxGGGGGRRRRR                   BBBBBxGGGGGRRRRR
    data = ((data & 0b1111100000000000) >>11) + ((data & 0b0000011111100000)<<0) + ((data & 0b0000000000011111)<<11);
    
	return data;
}

void Screen_HY28A_SRAM::_writeRegister(uint8_t command8, uint16_t data16)
{
    _writeCommand(command8);
    _writeData16(data16);
}

void Screen_HY28A_SRAM::_writeBeginSPI()
{
#if (FAST_DIGITALWRITE == 1)
    _pinScreenChipSelect.setLOW();
    
#else
    digitalWrite(_pinScreenChipSelect, LOW);
    
#endif
}

void Screen_HY28A_SRAM::_writeEndSPI()
{
#if (FAST_DIGITALWRITE == 1)
    _pinScreenChipSelect.setHIGH();
    
#else
    digitalWrite(_pinScreenChipSelect, HIGH);
    
#endif
}


void Screen_HY28A_SRAM::_writeSPI(uint8_t data8)
{
#if  (SPI_MODE == SOFTWARE_SPI)
    shiftOut(_pinScreenSerialDataMOSI, _pinTouchSerialClock, MSBFIRST, data8);
    
#else
    SPI_LCD.transfer(data8);
    
#endif
}

uint8_t Screen_HY28A_SRAM::_readSPI()
{
#if (SPI_MODE == SOFTWARE_SPI)
    uint8_t data8 = 0;
    data8 = shiftIn(_pinScreenSerialDataMISO, _pinScreenSerialClock, MSBFIRST);
    return data8;
    
#else
    return SPI_LCD.transfer(0);
    
#endif
}


// Communication, fast write
void Screen_HY28A_SRAM::_fastFill(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t colour)
{
    if (x1 > x2) _swap(x1, x2);
    if (y1 > y2) _swap(y1, y2);
    
    _setWindow(x1, y1, x2, y2);
    _writeCommand(0x0022);
    
    _writeBeginSPI();
    _writeSPI(SPI_START | SPI_WR | SPI_DATA);                                   // write : RS = 1, RW = 0
    
    uint8_t highColour = highByte(colour);
    uint8_t lowColour  = lowByte(colour);
    
    for (uint32_t t=(uint32_t)(y2-y1+1)*(x2-x1+1); t>0; t--) {
        _writeSPI(highColour);                                                  // write D8..D15
        _writeSPI(lowColour);                                                   // write D0..D7
    }    
    _writeEndSPI();

    _closeWindow();
}

void Screen_HY28A_SRAM::copyPasteArea(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t dx, uint16_t dy)
{
    uint16_t data;
    
    _closeWindow();
    
    for (uint16_t y=0; y<dy; y++) {
        for (uint16_t x=0; x<dx; x++) {
            _setCursor(x1+x, y1+y);
            data = _readData();
            
            HY28A_buffer[x][0] = highByte(data);
            HY28A_buffer[x][1] = lowByte(data);
        }
        
        _setWindow(x2, y2+y, x2+dx, y2+y);
        _writeCommand(0x0022);
        
        _writeBeginSPI();
        _writeSPI(SPI_START | SPI_WR | SPI_DATA);                               // write : RS = 1, RW = 0
        for (uint16_t x=0; x<dx; x++) {
            _writeSPI(HY28A_buffer[x][0]);                                            // write D8..D15
            _writeSPI(HY28A_buffer[x][1]);                                            // write D0..D7
        }
        _writeEndSPI();
    }
}

#if (USE_SPI_SRAM == 1)
SPIClass SPI_RAM(1);

void Screen_HY28A_SRAM::_beginSRAM()
{
    //    Serial.println("*** _beginSRAM");
    
    _pinSRAMChipSelectMSB.begin(PE_2);
    _pinSRAMChipSelectLSB.begin(PE_3);
    
    //    SPI_RAM.setModule(0);
    SPI_RAM.begin();
    SPI_RAM.setClockDivider(SPI_CLOCK_DIV4);                                    // for LM4F with 16000000
    SPI_RAM.setBitOrder(MSBFIRST);
    SPI_RAM.setDataMode(SPI_MODE0);                                             // SPI_MODE0
    
    _pinSRAMChipSelectMSB.setLOW();
    SPI_RAM.transfer(SRAM_WRITE_STATUS);
    SPI_RAM.transfer(SRAM_SEQUENCE_MODE);
    _pinSRAMChipSelectMSB.setHIGH();
    
    _pinSRAMChipSelectLSB.setLOW();
    SPI_RAM.transfer(SRAM_WRITE_STATUS);
    SPI_RAM.transfer(SRAM_SEQUENCE_MODE);
    _pinSRAMChipSelectLSB.setHIGH();
}

//void Screen_HY28A_SRAM::_writeSRAM(uint32_t &address, uint8_t dataHigh8, uint8_t dataLow8)
//{
//    // 131070 = 1024 * 1024 bits / 8 = 131072 bytes - 2 to be written
//    bool flag = false;
//    uint32_t localAddress = address;
//    
//    if (address < (uint32_t)131070) {
//        flag = true;
//    } else {
//        localAddress = address - (uint32_t)131070;
//    }
//    
//#if (FAST_DIGITALWRITE==1)
//    if (flag) _pinSRAMChipSelectLSB.setLOW();
//    else      _pinSRAMChipSelectMSB.setLOW();
//    
//    SPI_RAM.transfer(SRAM_WRITE);
//    SPI_RAM.transfer((localAddress >> 16) & 0xff);
//    SPI_RAM.transfer((localAddress >> 8) & 0xff);
//    SPI_RAM.transfer(localAddress);
//    SPI_RAM.transfer(dataHigh8);
//    SPI_RAM.transfer(dataLow8);
//    
//    if (flag) _pinSRAMChipSelectLSB.setHIGH();
//    else      _pinSRAMChipSelectMSB.setHIGH();
//    
//#else
//    if (flag) _pinSRAMChipSelectMSB.setLOW();
//    else      _pinSRAMChipSelectLSB.setLOW();
//    
//    SPI_RAM.transfer(SRAM_READ);
//    SPI_RAM.transfer((localAddress >> 16) & 0xff);
//    SPI_RAM.transfer((localAddress >> 8) & 0xff);
//    SPI_RAM.transfer(localAddress);
//    SPI_RAM.transfer(dataHigh8);
//    SPI_RAM.transfer(dataLow8);
//    
//    if (flag) _pinSRAMChipSelectMSB.setHIGH();
//    else      _pinSRAMChipSelectLSB.setHIGH();
//    
//#endif
//    
//    address = address + 2;
//}
//
//
//void Screen_HY28A_SRAM::_readSRAM(uint32_t &address, uint8_t &dataHigh8, uint8_t &dataLow8)
//{
//    bool flag = false;
//    uint32_t localAddress = address;
//    
//    if (address < (uint32_t)131070) {
//        flag = true;
//    } else {
//        localAddress = address - (uint32_t)131070;
//    }
//    
//#if (FAST_DIGITALWRITE==1)
//    if (flag) _pinSRAMChipSelectLSB.setLOW();
//    else      _pinSRAMChipSelectMSB.setLOW();
//    
//    SPI_RAM.transfer(SRAM_READ);
//    SPI_RAM.transfer((localAddress >> 16) & 0xff);
//    SPI_RAM.transfer((localAddress >> 8) & 0xff);
//    SPI_RAM.transfer(localAddress);
//    dataHigh8 = SPI_RAM.transfer(0);
//    dataLow8  = SPI_RAM.transfer(0);
//    
//    if (flag) _pinSRAMChipSelectLSB.setHIGH();
//    else      _pinSRAMChipSelectMSB.setHIGH();
//    
//#else
//    if (flag) _pinSRAMChipSelectMSB.setLOW();
//    else      _pinSRAMChipSelectLSB.setLOW();
//    
//    SPI_RAM.transfer(SRAM_READ);
//    SPI_RAM.transfer((localAddress >> 16) & 0xff);
//    SPI_RAM.transfer((localAddress >> 8) & 0xff);
//    SPI_RAM.transfer(localAddress);
//    dataHigh8 = SPI_RAM.transfer(0);
//    dataLow8  = SPI_RAM.transfer(0);
//    
//    if (flag) _pinSRAMChipSelectMSB.setHIGH();
//    else      _pinSRAMChipSelectLSB.setHIGH();
//    
//#endif
//    
//    address = address + 2;
//}

void Screen_HY28A_SRAM::_fastCopyAreaToSRAM(uint16_t x0, uint16_t y0, uint16_t dx, uint16_t dy, uint32_t &address)
{
    uint16_t data;
    uint32_t localAddress = address;
    
    if ((uint32_t)address+dx*dy < (uint32_t)131070) {
        
        for (uint16_t y=0; y<dy; y++) {
            localAddress = address + y*dx;
            
            _pinSRAMChipSelectMSB.setLOW();
            SPI_RAM.transfer(SRAM_WRITE);
            SPI_RAM.transfer((localAddress >> 16) & 0xff);
            SPI_RAM.transfer((localAddress >> 8) & 0xff);
            SPI_RAM.transfer(localAddress);
            
            for (uint16_t x=0; x<dx; x++) {
                _setCursor(x0+x, y0+y);
                data = _readData();
                
                HY28A_buffer[x][0] = highByte(data);
                HY28A_buffer[x][1] = lowByte(data);
                
                SPI_RAM.transfer(HY28A_buffer[x][0]);
            }
            _pinSRAMChipSelectMSB.setHIGH();
        
            _pinSRAMChipSelectLSB.setLOW();
            SPI_RAM.transfer(SRAM_WRITE);
            SPI_RAM.transfer((localAddress >> 16) & 0xff);
            SPI_RAM.transfer((localAddress >> 8) & 0xff);
            SPI_RAM.transfer(localAddress);

            for (uint16_t x=0; x<dx; x++) {
                SPI_RAM.transfer(HY28A_buffer[x][1]);
            }
            _pinSRAMChipSelectLSB.setHIGH();
        }
        _closeWindow();
        
        address = address + dx*dy;
    }
}

// Communication, fast read
void Screen_HY28A_SRAM::_fastPasteAreaFromSRAM(uint16_t x0, uint16_t y0, uint16_t dx, uint16_t dy, uint32_t &address, bool option)
{
    uint8_t dataHigh8, dataLow8;
    uint32_t localAddress = address;
    
    if ((uint32_t)address+dx*dy < (uint32_t)131070) {
        
        _setWindow(x0, y0, x0+dx-1, y0+dy-1);
        _setCursor(x0, y0);
        
        _writeBeginSPI();
        _writeSPI(SPI_START | SPI_WR | SPI_DATA);                                   // write : RS = 1, RW = 0
        
        for (uint16_t y=0; y<dy; y++) {
            localAddress = address + y*dx;
            
            _pinSRAMChipSelectMSB.setLOW();
            SPI_RAM.transfer(SRAM_READ);
            SPI_RAM.transfer((localAddress >> 16) & 0xff);
            SPI_RAM.transfer((localAddress >> 8) & 0xff);
            SPI_RAM.transfer(localAddress);
            for (uint16_t x=0; x<dx; x++) {
                HY28A_buffer[x][0] = SPI_RAM.transfer(0);
            }
            _pinSRAMChipSelectMSB.setHIGH();
            
            _pinSRAMChipSelectLSB.setLOW();
            SPI_RAM.transfer(SRAM_READ);
            SPI_RAM.transfer((localAddress >> 16) & 0xff);
            SPI_RAM.transfer((localAddress >> 8) & 0xff);
            SPI_RAM.transfer(localAddress);
            for (uint16_t x=0; x<dx; x++) {
                HY28A_buffer[x][1]  = SPI_RAM.transfer(0);
                
                if (option) {
                    _writeSPI(((HY28A_buffer[x][0] >> 1) & 0b11111000) | ((HY28A_buffer[x][0] & 0b00000111) >> 1));
                    _writeSPI(((HY28A_buffer[x][1] >> 1) & 0b11100000) | ((HY28A_buffer[x][1] & 0b00011111) >> 1));
                } else {
                    _writeSPI(HY28A_buffer[x][0]);                                              // write D8..D15
                    _writeSPI(HY28A_buffer[x][1]);                                               // write D0..D7
                }
            }
            _pinSRAMChipSelectLSB.setHIGH();
            
        }
        _writeEndSPI();
        
        address = address + dx*dy;
    }
}



//void Screen_HY28A_SRAM::_fastCopyAreaToSRAM(uint16_t x0, uint16_t y0, uint16_t dx, uint16_t dy, uint32_t &address)
//{
//    bool flag = false;
//    uint32_t localAddress = (uint32_t)address;
//    uint16_t data;
//
//    if ((uint32_t)address+dx*dy < (uint32_t)131070) {
//        flag = true;
//    } else if ((uint32_t)address < (uint32_t)131070) {
//        localAddress = (uint32_t)131070;
//    } else {
//        localAddress = (uint32_t)address - (uint32_t)131070;
//    }
//    Serial.print("address       =");
//    Serial.println(address, DEC);
//    Serial.print("address+dx*dy =");
//    Serial.println(address+dx*dy, DEC);
//    Serial.print("localAddress  =");
//    Serial.println(localAddress, DEC);
//    Serial.print("flag          =");
//    Serial.println(flag, DEC);
//
//#if (FAST_DIGITALWRITE==1)
//    if (flag) _pinSRAMChipSelectLSB.setLOW();
//    else      _pinSRAMChipSelectMSB.setLOW();
//#else
//    if (flag) _pinSRAMChipSelectMSB.setLOW();
//    else      _pinSRAMChipSelectLSB.setLOW();
//#endif
//
//    SPI_RAM.transfer(SRAM_WRITE);
//    SPI_RAM.transfer((localAddress >> 16) & 0xff);
//    SPI_RAM.transfer((localAddress >> 8) & 0xff);
//    SPI_RAM.transfer(localAddress);
//
//
//    _closeWindow();
//
//    for (uint16_t y=y0; y<y0+dy; y++) {
//        for (uint16_t x=x0; x<x0+dx; x++) {
//            _setCursor(x, y);
//            data = _readData();
//
//            SPI_RAM.transfer(highByte(data));
//            SPI_RAM.transfer(lowByte(data));
//        }
//    }
//
//#if (FAST_DIGITALWRITE==1)
//    if (flag) _pinSRAMChipSelectLSB.setHIGH();
//    else      _pinSRAMChipSelectMSB.setHIGH();
//#else
//    if (flag) _pinSRAMChipSelectMSB.setHIGH();
//    else      _pinSRAMChipSelectLSB.setHIGH();
//#endif
//
//    address = address + dx*dy;
//}
//
//// Communication, fast read
//void Screen_HY28A_SRAM::_fastPasteAreaFromSRAM(uint16_t x0, uint16_t y0, uint16_t dx, uint16_t dy, uint32_t &address, bool option)
//{
//    uint8_t highColour, lowColour;
//
//    bool flag = false;
//    uint32_t localAddress = address;
//    uint8_t dataHigh8, dataLow8;
//
//    if ((uint32_t)address+dx*dy < (uint32_t)131070) {
//        flag = true;
//    } else if ((uint32_t)address < (uint32_t)131070) {
//        localAddress = (uint32_t)131070;
//    } else {
//        localAddress = (uint32_t)address - (uint32_t)131070;
//    }
//
//    Serial.print("address       =");
//    Serial.println(address, DEC);
//    Serial.print("address+dx*dy =");
//    Serial.println(address+dx*dy, DEC);
//    Serial.print("localAddress  =");
//    Serial.println(localAddress, DEC);
//    Serial.print("flag          =");
//    Serial.println(flag, DEC);
//
//#if (FAST_DIGITALWRITE==1)
//    if (flag) _pinSRAMChipSelectLSB.setLOW();
//    else      _pinSRAMChipSelectMSB.setLOW();
//#else
//    if (flag) _pinSRAMChipSelectMSB.setLOW();
//    else      _pinSRAMChipSelectLSB.setLOW();
//#endif
//
//    SPI_RAM.transfer(SRAM_READ);
//    SPI_RAM.transfer((localAddress >> 16) & 0xff);
//    SPI_RAM.transfer((localAddress >> 8) & 0xff);
//    SPI_RAM.transfer(localAddress);
//
//    _setWindow(x0, y0, x0+dx-1, y0+dy-1);
//    _setCursor(x0, y0);
//
//    _writeBeginSPI();
//    _writeSPI(SPI_START | SPI_WR | SPI_DATA);                                   // write : RS = 1, RW = 0
//
//    for (uint16_t y=0; y<dy; y++) {
//        for (uint16_t x=0; x<dx; x++) {
//            dataHigh8 = SPI_RAM.transfer(0);
//            dataLow8  = SPI_RAM.transfer(0);
//
//            if (option) {
//                _writeSPI(((dataHigh8 >> 1) & 0b11111000) | ((dataHigh8 & 0b00000111) >> 1));
//                _writeSPI(((dataLow8  >> 1) & 0b11100000) | ((dataLow8  & 0b00011111) >> 1));
//            } else {
//                _writeSPI(dataHigh8);                                              // write D8..D15
//                _writeSPI(dataLow8);                                               // write D0..D7
//            }
//        }
//    }
//    _writeEndSPI();
//    _closeWindow();
//
//#if (FAST_DIGITALWRITE==1)
//    if (flag) _pinSRAMChipSelectLSB.setHIGH();
//    else      _pinSRAMChipSelectMSB.setHIGH();
//#else
//    if (flag) _pinSRAMChipSelectMSB.setHIGH();
//    else      _pinSRAMChipSelectLSB.setHIGH();
//#endif
//
//    address = address + dx*dy;
//}

void Screen_HY28A_SRAM::copyArea(uint16_t x0, uint16_t y0, uint16_t dx, uint16_t dy, uint32_t &address)
{
    _fastCopyAreaToSRAM(x0, y0, dx, dy, address);
}

void Screen_HY28A_SRAM::pasteArea(uint16_t x0, uint16_t y0, uint16_t dx, uint16_t dy, uint32_t &address, bool option)
{
    _fastPasteAreaFromSRAM(x0, y0, dx, dy, address, option);
}
#endif

// Touch
void Screen_HY28A_SRAM::_getOneTouch(uint8_t command, uint8_t &a, uint8_t &b)
{
    _pinTouchChipSelect.setLOW();
    
    shiftOut(_pinTouchSerialDataMOSI, _pinTouchSerialClock, MSBFIRST, command);
    a = shiftIn(_pinTouchSerialDataMISO, _pinTouchSerialClock, MSBFIRST);
    b = shiftIn(_pinTouchSerialDataMISO, _pinTouchSerialClock, MSBFIRST);
    
    _pinTouchChipSelect.setHIGH();
}

void Screen_HY28A_SRAM::_getRawTouch(uint16_t &x0, uint16_t &y0, uint16_t &z0)
{
    uint16_t z1, z2;
    uint8_t a, aa, b, c, cc, d;
    
    // May be needed for cleaning screen SPI communication for LM4F
    // #if defined(__LM4F120H5QR__)
    // _setPoint(0, 0, 0);
    // #endif
    
    delay(10);
    _getOneTouch(TOUCH_Z1 + 0x08 + 0x01, a, b);                                 // 8-bit
    _getOneTouch(TOUCH_Z2 + 0x08 + 0x01, c, d);
    
    z0 = a + (0x7f - c);
    if (z0 == 0x7f) z0 = 0;
    
    if (z0 > _touchTrim) {
        do {
            _getOneTouch(TOUCH_X + 0x00 + 0x01, a, b);                          // 12-bit
            _getOneTouch(TOUCH_Y + 0x00 + 0x01, c, d);
            delay(10);
            _getOneTouch(TOUCH_X + 0x00 + 0x01, aa, b);                         // 12-bit
            _getOneTouch(TOUCH_Y + 0x00 + 0x01, cc, d);
        } while ( (a != aa) || (c != cc) );
        
        x0 = a<<4 | b >> 4;
        y0 = c<<4 | d >> 4;
    }
}

#endif                                                                          // end USE_SPI_SRAM
